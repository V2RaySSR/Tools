<table id="{{$table_id}}" class="table table-hover">
    <thead>
        <tr>
            <th>用户名</th>
            <th>Email</th>
            <th>注册时间</th>
            <th>状态</th>
            <th>API</th>
            <th>权限组</th>
            <th>删除</th>
        </tr>
    </thead>
</table>
