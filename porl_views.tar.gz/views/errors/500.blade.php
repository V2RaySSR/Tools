@extends('layouts.errors')

@section('content')
<h1>500</h1>
<p>Oh dear. Something seems to have gone awry.</p>
<h4>Please contact an administrator to report this issue.</h4>
@endsection
